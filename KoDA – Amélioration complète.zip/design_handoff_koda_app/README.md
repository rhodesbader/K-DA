# Handoff : KŌDA App

## Aperçu
Application mobile KŌDA (super-app sports de combat) : accueil, feed, réseau, chat, profil (avec palmarès compétitions), paramètres, abonnement. Ce dossier contient le prototype HTML complet à jour, pour donner à une autre IA ou un développeur le contexte exact des derniers changements.

## À propos des fichiers
Les fichiers de ce dossier sont des **références de design faites en HTML** (prototypes montrant l'apparence et le comportement voulus), pas du code de production à copier tel quel. La tâche consiste à **recréer ces écrans HTML dans l'environnement réel du projet** (React Native, SwiftUI, Flutter, etc.) en respectant l'architecture déjà en place — ou, s'il n'existe pas encore d'environnement, à choisir le framework le plus adapté.

## Fidélité
**Haute fidélité (hifi)** : couleurs, typographie, espacements et interactions finaux. Les écrans doivent être recréés au pixel près avec les composants déjà existants dans le codebase cible.

## Dernier changement (à noter en priorité)
Écran "Ajouter un résultat" (palmarès, profil) enrichi :
- Sélecteur de **discipline** (chips : Boxing, MMA, BJJ, Muay Thai, Judo)
- Champ optionnel **Adversaire / Salle**
- Champ optionnel **Notes** (méthode de victoire, sensations, points à travailler)
- Ces infos s'affichent désormais dans les cartes du palmarès, sur le profil perso ET le profil public (ligne méta : date · discipline · résultat · adversaire, + notes en dessous)

## Design system
Couleurs, typographie et composants suivent le **KŌDA Design System v1.0** :
- Fond Obsidian `#0A0A0A`, surfaces Iron `#1C1C1C`, bordures Graphite `#3A3A3A` (hairline 0.5px)
- Texte Bone White `#F5F0E8`, texte secondaire Ash `#8A8A8A`
- Accent unique : Combat Red `#C8102E` (+ surface rouge `#2A0A0A`)
- Vert `#5DCAA5` réservé aux badges vérifiés / succès
- Typo : **Bebas Neue** (titres, tout en capitales), **DM Sans** (corps de texte)
- Radius : 8px (boutons/inputs), 12px (cartes), 999px (chips/pills)
- Ton : direct, factuel, zéro emoji, séparateur `·`

## Fichiers
- `KODA App.dc.html` — fichier principal de l'app (tous les écrans : onboarding, home, feed, réseau, chat, profil, paramètres, abonnement, timer, etc.)
- `image-slot.js` — composant utilisé pour la photo de profil (fix de dimensionnement 84×84 appliqué)
- `design_system_guide.md` — guide complet du design system KŌDA (tokens, ton, composants)

## État des données
Toutes les données utilisateur (profil édité, compétitions ajoutées, abonnement, etc.) sont persistées en `localStorage` du navigateur — c'est un prototype, pas une vraie base de données.
